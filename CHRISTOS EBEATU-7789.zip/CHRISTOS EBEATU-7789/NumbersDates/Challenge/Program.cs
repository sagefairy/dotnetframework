﻿// See https://aka.ms/new-console-template for more information

string input;
do
{
    Console.WriteLine("Enter a date or 'exit'");
    input = Console.ReadLine().ToLower();
    DateTime result;
    DateTime dt = DateTime.Now;

    if (input != "exit"){
        try{
            result = DateTime.Parse(input);
            TimeSpan interval = dt - result;

        if(interval.Days > 0){
            Console.WriteLine("The date is {0} days in the past", interval.Days);
        }

        else if(interval.Days < 0){
            Console.WriteLine("The date is {0} days in the future", -interval.Days);
        }

        else{
            Console.WriteLine("The date is in the present");
        }
        
        }
        catch(FormatException e){
            Console.WriteLine($"Could not parse '{input}' : {e.Message}");
        }
        
    }
    /*
    if (input != "exit"){
        date = DateOnly.Parse(input);
        Console.WriteLine(date);
    }*/
}
while(input != "exit");






